# README

Midterm exam for Intro to Data.
